﻿namespace CargoTransport.Models
{
    public class Cargo
    {
        public int Id { get; }
        public string Destination { get; }

        public Cargo(int id, string destination)
        {
            Id = id;
            Destination = destination;
        }

        public override string ToString()
        {
            return $"Cargo {Id} -> {Destination}";
        }
    }
}