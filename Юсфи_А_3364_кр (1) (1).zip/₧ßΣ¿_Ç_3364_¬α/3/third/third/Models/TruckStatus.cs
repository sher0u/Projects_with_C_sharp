﻿namespace CargoTransport.Models
{
    public enum TruckStatus
    {
        Idle,
        Loading,
        OnTrip
    }
}