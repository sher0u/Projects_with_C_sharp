﻿using System;
using System.Collections.Generic;
using CargoTransport.Services;


namespace CargoTransport.Models
{
    public class Truck
    {
        public string Name { get; }
        public int Capacity { get; }
        public TruckStatus Status { get; private set; }
        public List<Cargo> LoadedCargo { get; }
        public string CurrentDestination { get; private set; }

        public Truck(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            LoadedCargo = new List<Cargo>();
            Status = TruckStatus.Idle;
        }

        public bool LoadCargo(Cargo cargo)
        {
            if (LoadedCargo.Count < Capacity)
            {
                LoadedCargo.Add(cargo);
                CurrentDestination = cargo.Destination;
                return true;
            }
            return false;
        }

        public void StartTrip()
        {
            if (LoadedCargo.Count > 0)
            {
                Status = TruckStatus.OnTrip;
                Logger.Log($"{Name} started the trip to {CurrentDestination} with {LoadedCargo.Count} cargo(s).");
            }
        }

        public void CompleteTrip()
        {
            Status = TruckStatus.Idle;
            LoadedCargo.Clear();
            Logger.Log($"{Name} has completed the trip and is now idle.");
            CurrentDestination = null;
        }

        public override string ToString()
        {
            return $"{Name} [Capacity: {Capacity}, Status: {Status}, Destination: {CurrentDestination ?? "None"}]";
        }
    }
}