﻿using System;
using System.Collections.Generic;
using CargoTransport.Models;
using CargoTransport.Services;

namespace CargoTransport
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the warehouse and trucks
            var warehouse = new Warehouse();
            var trucks = new List<Truck>
            {
                new Truck("Truck 1", 5),
                new Truck("Truck 2", 10),
                new Truck("Truck 3", 8)
            };

            var scheduler = new TruckScheduler(trucks);
            var statsService = new StatisticsService("statistics.csv");

            // Generate cargo and assign to trucks
            Console.WriteLine("Generating cargo...");
            var cargoList = warehouse.GenerateCargo(20);
            Console.WriteLine("Assigning cargo to trucks...");
            scheduler.AssignCargoToTrucks(cargoList);

            // Dispatch trucks
            Console.WriteLine("Dispatching trucks...");
            scheduler.DispatchTrucks();

            // Log statistics
            Console.WriteLine("Logging statistics...");
            statsService.LogStatistics(trucks);

            Console.WriteLine("Simulation completed. Check 'log.txt' for logs and 'statistics.csv' for statistics.");
        }
    }
}