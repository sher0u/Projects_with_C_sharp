﻿using System;
using System.Collections.Generic;
using CargoTransport.Models;


namespace CargoTransport.Services
{
    public class Warehouse
    {
        private readonly Random _random = new Random();
        private readonly List<string> _destinations = new List<string> { "City A", "City B", "City C" };
        private int _cargoCounter = 0;

        public List<Cargo> GenerateCargo(int count)
        {
            var cargoList = new List<Cargo>();
            for (int i = 0; i < count; i++)
            {
                var destination = _destinations[_random.Next(_destinations.Count)];
                cargoList.Add(new Cargo(++_cargoCounter, destination));
            }
            return cargoList;
        }
    }
}