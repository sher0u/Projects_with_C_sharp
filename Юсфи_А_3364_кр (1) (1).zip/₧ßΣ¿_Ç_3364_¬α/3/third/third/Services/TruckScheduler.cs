﻿using System;
using System.Collections.Generic;
using System.Linq;
using CargoTransport.Models;

namespace CargoTransport.Services
{
    public class TruckScheduler
    {
        private readonly List<Truck> _trucks;

        public TruckScheduler(List<Truck> trucks)
        {
            _trucks = trucks;
        }

        public void AssignCargoToTrucks(List<Cargo> cargoList)
        {
            foreach (var cargo in cargoList)
            {
                var availableTruck = _trucks.FirstOrDefault(truck => truck.Status == TruckStatus.Idle && 
                                                                     (truck.LoadedCargo.Count == 0 || truck.CurrentDestination == cargo.Destination));
                if (availableTruck != null)
                {
                    if (availableTruck.LoadCargo(cargo))
                    {
                        Logger.Log($"{availableTruck.Name} loaded Cargo {cargo.Id} for destination {cargo.Destination}");
                    }
                }
            }
        }

        public void DispatchTrucks()
        {
            foreach (var truck in _trucks.Where(truck => truck.LoadedCargo.Count > 0))
            {
                truck.StartTrip();
                truck.CompleteTrip();
            }
        }
    }
}