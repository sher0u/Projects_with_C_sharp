﻿using System.Collections.Generic;
using System.IO;
using CargoTransport.Models;

namespace CargoTransport.Services
{
    public class StatisticsService
    {
        private readonly string _filePath;

        public StatisticsService(string filePath)
        {
            _filePath = filePath;
        }

        public void LogStatistics(List<Truck> trucks)
        {
            var logData = new List<string>();
            foreach (var truck in trucks)
            {
                logData.Add(truck.ToString());
            }

            File.WriteAllLines(_filePath, logData);
        }
    }
}