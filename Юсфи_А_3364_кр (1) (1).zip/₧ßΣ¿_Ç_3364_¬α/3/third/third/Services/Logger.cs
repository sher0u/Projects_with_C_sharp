﻿using System;
using System.IO;

namespace CargoTransport.Services
{
    public static class Logger
    {
        private static readonly string LogFilePath = "log.txt";

        public static void Log(string message, string logType = "INFO")
        {
            string logMessage = $"[{DateTime.Now:HH:mm:ss}] [{logType}] {message}";
            Console.WriteLine(logMessage);
            File.AppendAllText(LogFilePath, logMessage + Environment.NewLine);
        }

    }
}