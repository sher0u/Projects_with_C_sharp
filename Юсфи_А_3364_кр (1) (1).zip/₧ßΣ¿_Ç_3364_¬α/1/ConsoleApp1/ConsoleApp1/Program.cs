﻿namespace Shooooping
{
    class Market_Electronics
    {
        static void Main(string[] args)
        {
            try
            {
                LoggingBase.Info("magazine  started working");

                
                var shop = Shop.Instance;
                User user = new User();

                // Start the simulation.
                OpenSHop(user);

                shop.Close();
                LoggingBase.Info("magazine  Finished working");
            }
            catch (Exception ex)
            {
                LoggingBase.Error($"Unhandled exception: {ex.Message}");
                Console.WriteLine("An unknown error has occurred.");
            }
        }
        static void OpenSHop(User user)
        {
            try
            {
                // Begin shopping actions.
                user.Shopping();
                user.ExitShop();
            }
            catch (Exception ex)
            {
                LoggingBase.Error($"Simulation error: {ex.Message}");
                Console.WriteLine("An unknown error has occurred.");
            }
        }
    }
}
