﻿namespace Shooooping
{
    public static class LoggingBase
    {
        private static readonly string FilePath = "log.log"; // Path to the log file.

        // Method to log informational messages.
        public static void Info(string message) => Log(LogLevel.Info, message);

        // Method to log error messages.
        public static void Error(string message) => Log(LogLevel.Error, message);

        
        private static void Log(LogLevel level, string message)
        {
            string logMessage = $"{DateTime.Now} [{level.ToString().ToUpper()}]: {message}";

            try
            {
                File.AppendAllText(FilePath, logMessage + Environment.NewLine); // Append the log to the file.
            }
            catch (Exception ex)
            {
                // If writing to the log file fails, write to the console.
                Console.WriteLine($"Failed to write to log file: {ex.Message}");
            }
        }
    }

    
    public enum LogLevel
    {
        Info = 1, // Informational messages.
        Error = 2 // Error messages.
    }
}