﻿using Shooooping;
namespace Shooooping
{
    public interface IMAG
    {
        int Id { get; } 
        decimal CheckValue { get; } 
        void EnterShop();
        void ExitShop(); 
    }
    public class Cart
    {
        private readonly List<Articels> products = new List<Articels>();

        public void AddProduct(Articels articels)
        {
            products.Add(articels);
            LoggingBase.Info($"Articels {articels.Name} added to the cart.");
        }

        public decimal Pay()
        {
            decimal total = 0;
            foreach (var product in products)
            {
                total += product.Price;
            }
            products.Clear();
            LoggingBase.Info($"Total payment of {total} rubles made for products.");
            return total;
        }

        public void Clear()
        {
            products.Clear();
            LoggingBase.Info("The cart has been cleared.");
        }

        public IReadOnlyList<Articels> Products => products.AsReadOnly();
    }
}

   
    public abstract class Cleint : IMAG
    {
        protected static int idCounter = 0; // Counter for generating unique IDs.
        public Cart Cart { get; } = new Cart(); // The customer's shopping cart.
        public int Id { get; } // Unique identifier for the customer.
        public decimal CheckValue { get; private set; } // Total amount spent by the customer.

        public Cleint()
        {
            Id = ++idCounter;
            EnterShop();
        }

        public void AddToCheck(decimal amount) => CheckValue += amount;

        public abstract void Shopping();

        public void EnterShop() => LoggingBase.Info($"Cleint {Id} has entered the shop.");

        public void ExitShop() => LoggingBase.Info($"Cleint {Id} made purchases worth {CheckValue} rubles and left the shop.");
    }
    public class User : Cleint
    {
        public override void Shopping()
        {
            while (true)
            {
                Console.WriteLine("-----Welcome to Kader Store:---- \nSelect action: \n1. Go to Articles \n2. Pay for things \n3. Leave the Magazine");
                

                if (!int.TryParse(Console.ReadLine(), out int action))
                {
                    Console.WriteLine("Invalid input. Try again.");
                    continue;
                }

                switch (action)
                {
                    case 1:
                        ShelfActions();
                        break;
                    case 2:
                        AddToCheck(Cart.Pay());
                        LoggingBase.Info($"User {Id} paid for the purchases.");
                        Console.WriteLine($"You have made purchases worth {CheckValue} $.");
                        break;
                    case 3:
                        Cart.Clear();
                        return;
                    default:
                        Console.WriteLine("Error: unknown action.");
                        break;
                }
            }
        }

        private void ShelfActions()
        {
            var shop = Shop.Instance;
            while (true)
            {
                Console.WriteLine(shop.ProductsQuantity > 0 ? "Enter product ID to add to your cart, or 0 to exit." : "No products left on the shelf, enter 0 to leave.");
                Console.WriteLine("1-Ipad Air 2024 ----- 999$");
                Console.WriteLine("2-MacBook Pro 2024 ----- 1999$");
                Console.WriteLine("3-Dell Xps---- 499$");
                
                if (!int.TryParse(Console.ReadLine(), out int action) || action < 0) continue;

                if (action == 0) break;

                try
                {
                    var product = shop.GetProductById(action);
                    Cart.AddProduct(product);
                    Console.WriteLine($"Articels {product.Name} has been added to your cart.");
                }
                catch (Art_AlreadyExistsException)
                {
                    Console.WriteLine("Articels not found.");
                }
            }
        }
    }
