﻿namespace Shooooping
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    public class Articels
    {
        private static int idCounter = 1; 

        public int Id { get; } // Unique identifier for the product.
        public string Name { get; } // Name of the product.
        public decimal Price { get; } // Price of the product.

        public Articels(string name, decimal price)
        {
            Id = idCounter++;
            Name = name;
            Price = price;
            LoggingBase.Info($"Articels {name} created");
        }
    }
    public abstract class ArtList
    {
        protected abstract List<Articels> Products { get; }

        
        public string GetProductsListAsString()
        {
            return string.Join("\n", Products.Select(p => $"{p.Name} - {p.Price}"));
        }

      
        public virtual void AddArt(Articels articels)
        {
            if (Products.Contains(articels))
            {
                 LoggingBase.Error($"Error adding articels {articels.Name} since it is already on the list");
                throw new Art_AlreadyExistsException($"Articels with Id {articels.Id} already exists.");
            }

            Products.Add(articels);
        }
        public void AddArt(IEnumerable<Articels> products)
        {
            foreach (var product in products)
            {
                AddArt(product);
            }
        }
        public virtual void RemoveProduct(Articels articels)
        {
            if (!Products.Remove(articels))
            {
                throw new ART_NotFoundException($"Articels with Id {articels.Id} not found.");
            }
        }
        public Articels GetProductById(int id)
        {
            return Products.FirstOrDefault(p => p.Id == id) 
                ?? throw new ART_NotFoundException($"Articels with Id {id} not found.");
        }

        public virtual void Clear() => Products.Clear();

     
        public int ProductsQuantity => Products.Count;
    }
    public class Shop : ArtList
    {
        private static readonly List<Articels> products = new List<Articels>();
        protected override List<Articels> Products => products;
        private static decimal revenue = 0;

        protected Shop()
        {
            AddArt(new[]
            {
                new Articels("Ipad Air 2024", 999),
                new Articels("MacBook Pro 2024", 1999),
                new Articels("Dell Xps", 499),
            });

             LoggingBase.Info("The store warehouse is filled with Articels");
        }
        private static readonly Shop instance = new Shop();
        public static Shop Instance => instance;
        public void Earn(decimal amount)
        {
            if (amount < 0)
                throw new ArgumentException("Revenue cannot be negative.", nameof(amount));

            revenue += amount;
        }

        public decimal Revenue => revenue;

        
        public void Close()
        {
            Clear();
             LoggingBase.Info($"The store has closed. Revenue during operation amounted to {Revenue} $.");
        }
    }
    public class Art_AlreadyExistsException : Exception
    {
        public Art_AlreadyExistsException(string message) : base(message)
        {
        }

        public Art_AlreadyExistsException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
    public class ART_NotFoundException : Exception
    {
        public ART_NotFoundException(string message) : base(message)
        {
        }

        public ART_NotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}   
