﻿using System;


namespace GraphAlgorithms
{
    // This class implements the Hungarian Algorithm to solve the assignment problem.
    public sealed class HungarianAlgorithm
    {
        private readonly int[,] _costMatrix; // The cost matrix representing the cost of assigning workers to jobs
        private int _inf; // A large value used for initializing slack values
        private int _n; // The number of workers or jobs (assumed to be square matrix)
        private int[] _lx; // Labels for workers
        private int[] _ly; // Labels for jobs
        private bool[] _s; // Boolean array to track which workers are in the tree
        private bool[] _t; // Boolean array to track which jobs are in the tree
        private int[] _matchX; // Stores the job assigned to each worker
        private int[] _matchY; // Stores the worker assigned to each job
        private int _maxMatch; // The number of matches found so far
        private int[] _slack; // Slack values to facilitate finding augmenting paths
        private int[] _slackx; // Array to store the worker that caused a particular slack
        private int[] _prev; // Array to remember the previous worker in an augmenting path

        public HungarianAlgorithm(int[,] costMatrix)
        {
            _costMatrix = costMatrix;// Initialize the cost matrix
        }

        public int[] Run()
        {
            _n = _costMatrix.GetLength(0);// Get the number of workers/jobs (assuming a square matrix)
            // Initialize arrays for labels, matches, and other data structures

            _lx = new int[_n];
            _ly = new int[_n];
            _s = new bool[_n];
            _t = new bool[_n];
            _matchX = new int[_n];
            _matchY = new int[_n];
            _slack = new int[_n];
            _slackx = new int[_n];
            _prev = new int[_n];
            _inf = int.MaxValue;// Set the infinity value to max integer value

            InitMatches();// Initialize all matches to -1 (no match yet)

            if (_n != _costMatrix.GetLength(1)) // // Check if the matrix is square
                return null;

            InitLbls();// Initialize labels for workers and jobs

            _maxMatch = 0;// Initially, no matches have been made

            InitialMatching();// Perform initial matching based on the cost matrix

            var q = new Queue<int>(); // Queue to store workers that are currently being considered
            // Loop until all workers have been matched
            while (_maxMatch != _n)
            {
                q.Clear();

                InitSt();// Reset the s and t arrays

                var root = 0;// Root worker for augmenting path
                int x;
                var y = 0;
                // Find the first worker that is not yet matched and add to the queue
                for (x = 0; x < _n; x++)
                {
                    if (_matchX[x] != -1) continue;
                    q.Enqueue(x);
                    root = x;
                    _prev[x] = -2;// Mark the root with a special value

                    _s[x] = true;// Add to the s set
                    break;
                }
                // Initialize slack values for all jobs
                for (var i = 0; i < _n; i++)
                {
                    _slack[i] = _costMatrix[root, i] - _lx[root] - _ly[i];
                    _slackx[i] = root;
                }
                // Augment the matching using a breadth-first search (BFS) approach

                while (true)
                {
                    while (q.Count != 0)
                    {
                        x = q.Dequeue();// Dequeue a worker
                        var lxx = _lx[x];
                        for (y = 0; y < _n; y++)
                        {
                            // Check if the current job can be matched with the worker
                            if (_costMatrix[x, y] != lxx + _ly[y] || _t[y]) continue;
                            if (_matchY[y] == -1) break;// Found an augmenting path, break out
                            _t[y] = true; 
                            q.Enqueue(_matchY[y]);// Enqueue the matched worker

                            AddToTree(_matchY[y], x);// Add the matched worker to the tree
                        }
                        if (y < _n) break;// If we found an augmenting path, break the loop
                    }
                    if (y < _n) break;
                    UpdateLabels();// Update the labels based on slack values

                    for (y = 0; y < _n; y++)
                    {
                        if (_t[y] || _slack[y] != 0) continue;
                        if (_matchY[y] == -1)
                        {
                            x = _slackx[y];// We found an unmatched job
                            break;
                        }
                        _t[y] = true;
                        if (_s[_matchY[y]]) continue;
                        q.Enqueue(_matchY[y]);
                        AddToTree(_matchY[y], _slackx[y]);
                    }
                    if (y < _n) break;
                }

                _maxMatch++;

                int ty;
                for (int cx = x, cy = y; cx != -2; cx = _prev[cx], cy = ty)
                {
                    ty = _matchX[cx];
                    _matchY[cy] = cx;
                    _matchX[cx] = cy;
                }
            }

            return _matchX;
        }

        private void InitMatches()
        {
            for (var i = 0; i < _n; i++)
            {
                _matchX[i] = -1;
                _matchY[i] = -1;
            }
        }

        private void InitSt()
        {
            for (var i = 0; i < _n; i++)
            {
                _s[i] = false;
                _t[i] = false;
            }
        }

        private void InitLbls()
        {
            for (var i = 0; i < _n; i++)
            {
                var minRow = _costMatrix[i, 0];
                for (var j = 0; j < _n; j++)
                {
                    if (_costMatrix[i, j] < minRow) minRow = _costMatrix[i, j];
                    if (minRow == 0) break;
                }
                _lx[i] = minRow;
            }
            for (var j = 0; j < _n; j++)
            {
                var minColumn = _costMatrix[0, j] - _lx[0];
                for (var i = 0; i < _n; i++)
                {
                    if (_costMatrix[i, j] - _lx[i] < minColumn) minColumn = _costMatrix[i, j] - _lx[i];
                    if (minColumn == 0) break;
                }
                _ly[j] = minColumn;
            }
        }

        private void UpdateLabels()
        {
            var delta = _inf;
            for (var i = 0; i < _n; i++)
                if (!_t[i])
                    if(delta > _slack[i])
                        delta = _slack[i];
            for (var i = 0; i < _n; i++)
            {
                if (_s[i])
                    _lx[i] = _lx[i] + delta;
                if (_t[i])
                    _ly[i] = _ly[i] - delta;
                else _slack[i] = _slack[i] - delta;
            }
        }

        private void AddToTree(int x, int prevx)
        {
            _s[x] = true;
            _prev[x] = prevx;

            var lxx = _lx[x];
            for (var y = 0; y < _n; y++)
            {
                if (_costMatrix[x, y] - lxx - _ly[y] >= _slack[y]) continue;
                _slack[y] = _costMatrix[x, y] - lxx - _ly[y];
                _slackx[y] = x;
            }
        }

        private void InitialMatching()
        {
            for (var x = 0; x < _n; x++)
            {
                for (var y = 0; y < _n; y++)
                {
                    if (_costMatrix[x, y] != _lx[x] + _ly[y] || _matchY[y] != -1) continue;
                    _matchX[x] = y;
                    _matchY[y] = x;
                    _maxMatch++;
                    break;
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            int[,] costMatrix = new int[7, 7]
            {
                { 21, 21, 37, 29, 30, 33, 45 },
                { 16, 16, 48, 43, 38, 44, 56 },
                { 19, 16, 42, 46, 44, 50, 59 },
                { 25, 16, 29, 50, 48, 54, 66 },
                { 24, 16, 34, 29, 42, 48, 57 },
                { 16, 15, 16, 16, 16, 15, 16 },
                { 36, 16, 46, 38, 36, 36, 75 }
            };

            HungarianAlgorithm ha = new HungarianAlgorithm(costMatrix);
            int[] result = ha.Run();
            
            int totalCost = 0;
            // Output the result
            for (int i = 0; i < result.Length; i++)
            {
                Console.WriteLine($"Worker {i + 1} assigned to job {result[i] + 1} with cost {costMatrix[i, result[i]]}");
                totalCost += costMatrix[i, result[i]];
            }
            
            // Output the sum of all assignment costs
            Console.WriteLine($"Total Sum of Costs: {totalCost}");
        }
    }
}
